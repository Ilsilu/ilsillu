my_dict = {'mama' : 1988, 'papa' :1985, 'son' : 2010}
print(my_dict)
print(my_dict['papa'])
my_dict['sister'] = 2012
print(my_dict)
my_dict.update({'broter' : 2013,
                'grandmama' : 1961})
print(my_dict)
print(my_dict['mama'])
del my_dict['mama']
print(my_dict)
my_set = {8, 9, 7, 8, 8, 9, 7}
print(my_set)
print(my_set.add(11))
print(my_set.add(12))
print(my_set)
print(my_set.remove(12))
print(my_set)

